// Importez les modules nécessaires
import { Injectable } from "@nestjs/common";

export const constantes = {
  idVehicule: "2dc94b3e-6efd-4d0a-a2b9-07d2060a73c4",
  idConducteur: "0404384a-be8d-4675-9f36-1d6995a00c34 ",
  idVoyage: "36937107-e2c9-4ca2-9c02-16890466c9da",
  idUtilisateur: "64fb5a8d-06d8-4f88-938a-b8e3af2341a1",
  hostbackend: "192.168.221.67:8080",
};
