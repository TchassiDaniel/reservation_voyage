import ReservationsHistory from "./components/HistoriqueReservation/ReservationsHistory";

const HistoriquePage = () => {
  return (
    <div>
      <ReservationsHistory />
    </div>
  );
};

export default HistoriquePage;
